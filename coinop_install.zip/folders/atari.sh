 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Atari"

cd $OutputRoot

create "$MainDir"

copyfile "Asteroids.mra" "_Asteroid"
copyfile "Asteroids Deluxe.mra" "_Asteroids Deluxe"
copyfile "Black Widow.mra" "_Black Widow"
copyfile "Breakout.mra" "_Breakout"
copyfile "Breakout (TTL).mra" "_Breakout"
copyfile "Canyon Bomber.mra" "_Canyon Bomber"
copyfile "Centipede.mra" "_Centipede"
copyfile "Centipede (Rev 3).mra" "_Centipede"
copyfile "Centipede (Rev 4).mra" "_Centipede"
copyfile "Centipede (revision 4).mra" "_Centipede"
copyfile "Discs of Tron.mra" "_Discs of Tron"
copyfile "Dominos.mra" "_Dominos"
copyfile "Food Fight.mra" "_Food Fight"
copyfile "Food Fight (Rev 3).mra" "_Food Fight"
copyfile "Gauntlet (rev 14).mra" "_Gauntlet"
copyfile "Gauntlet II.mra" "_Gauntlet II"
copyfile "Gravitar.mra" "_Gravitar"
copyfile "Gravitar (Ver 3).mra" "_Gravitar"
copyfile "Indiana Jones.mra" "_Indiana Jones"
copyfile "Lunar Battle.mra" "_Lunar Battle"
copyfile "Lunar Battle (Prototype).mra" "_Lunar Battle"
copyfile "Lunar Lander.mra" "_Lunar Lander"
copyfile "Space Race.mra" "_Space Race"
copyfile "Space Race [TTL].mra" "_Space Race"
copyfile "Sprint 1.mra" "_Sprint 1"
copyfile "Sprint 2.mra" "_Sprint 2"
copyfile "Super Breakout.mra" "_Super Breakout"
copyfile "Super Breakout (Rev 04).mra" "_Super Breakout"
copyfile "Tetris (cocktail set 1).mra" "_Atari Tetris"
copyfile "Tetris (Cocktail, Set 1).mra" "_Atari Tetris"
copyfile "Tetris.mra" "_Atari Tetris"
copyfile "Tron.mra" "_Tron"
copyfile "Vindicators Part II (rev 3).mra" "_Vindicators part II"

symlinkfolder "_Asteroid"
symlinkfolder "_Asteroids Deluxe"
symlinkfolder "_Black Widow"
symlinkfolder "_Breakout"
symlinkfolder "_Canyon Bomber"
symlinkfolder "_Centipede"
symlinkfolder "_Discs of Tron"
symlinkfolder "_Dominos"
symlinkfolder "_Food Fight"
symlinkfolder "_Gauntlet"
symlinkfolder "_Gauntlet II"
symlinkfolder "_Gravitar"
symlinkfolder "_Indiana Jones"
symlinkfolder "_Lunar Battle"
symlinkfolder "_Lunar Lander"	
symlinkfolder "_Space Race"
symlinkfolder "_Sprint 1"
symlinkfolder "_Sprint 2"
symlinkfolder "_Super Breakout"
symlinkfolder "_Tron"
symlinkfolder "_Tetris" "_Atari Tetris"
symlinkfolder "_Vindicators part II"


exit 0