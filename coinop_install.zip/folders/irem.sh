 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem"

cd $OutputRoot

create "$MainDir"

copyfile "Crazy Climber.mra" "_Crazy Climber"
copyfile "Moon Patrol.mra" "_Moon Patrol"
copyfile "Traverse USA - Zippy Race.mra" "_Traverse USA"
copyfile "Traverse USA- Zippy Race (US).mra" "_Traverse USA"
copyfile "Penguin-Kun_Wars.mra" "_Penguin-Kun_Wars"
copyfile "Penguin-Kun_Wars_Japan.mra" "_Penguin-Kun_Wars"
copyfile "Shot Rider (B-Board 89624B-1).mra" "_Shot Rider"
copyfile "Shot Rider.mra" "_Shot Rider"

symlinkfolder "_Crazy Climber"
symlinkfolder "_Moon Patrol"
symlinkfolder "_Shot Rider"
symlinkfolder "_Traverse USA"


exit 0