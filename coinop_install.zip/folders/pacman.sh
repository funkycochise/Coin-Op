 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Pacman"

cd $OutputRoot

#create "$MainDir"

copyfile "Alibaba 40 Thieves.mra" "_Pacman"
copyfile "Beastie Feastie.mra" "_Pacman"
copyfile "Birdiy.mra" "_Pacman"
copyfile "Crazy Otto.mra" "_Pacman"
copyfile "Crush Roller.mra" "_Pacman"
copyfile "Dream Shopper.mra" "_Pacman"
copyfile "Eeekk!.mra" "_Pacman"
copyfile "Eggor.mra" "_Pacman"
copyfile "Eyes.mra" "_Pacman"
copyfile "Gorkans.mra" "_Pacman"
copyfile "Jump Shot.mra" "_Pacman"
copyfile "Lizard Wizard.mra" "_Pacman"
copyfile "Mr. TNT.mra" "_Pacman"
copyfile "Ms. Pacman.mra" "_Pacman"
copyfile "Pac-Man (Midway).mra" "_Pacman"
copyfile "Pacman Club.mra" "_Pacman"
copyfile "Pacman Plus.mra" "_Pacman"
copyfile "Pacmanic Miner.mra" "_Pacman"
copyfile "Ponpoko.mra" "_Pacman"
copyfile "Puck Man (Japan set 1).mra" "_Pacman"
copyfile "Super Glob.mra" "_Pacman"
copyfile "The Glob.mra" "_Pacman"
copyfile "Van-Van Car.mra" "_Pacman"
copyfile "Woodpecker.mra" "_Pacman"

symlinkfolder "_Pacman"

exit 0