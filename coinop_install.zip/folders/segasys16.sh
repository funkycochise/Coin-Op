 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-System16"

cd $OutputRoot

create "$MainDir"

copyfile "Action Fighter (World, S16A) [FD1089A 317-0018].mra" "_Action Fighter"
copyfile "Alex Kidd The Lost Stars (Set 2, World, S16A) [No Protection].mra" "_Alex Kidd"
copyfile "Body Slam (World, S16) [8751 317-0015].mra" "_Body Slam"
copyfile "Fantasy Zone (Rev A, World, S16A) [No Protection].mra" "_Fantasy Zone"
copyfile "Quartet 2 (World, S16A) [No Protection].mra" "_Quartet 2"
copyfile "Shinobi (Set 6, World, S16A) [No Protection].mra" "_Shinobi"

symlinkfolder "_Action Fighter"
symlinkfolder "_Alex Kidd"
symlinkfolder "_Alien Syndrome"
symlinkfolder "_Body Slam"
symlinkfolder "_Fantasy Zone"
symlinkfolder "_Passing Shot"
symlinkfolder "_Quartet 2"
symlinkfolder "_Shinobi"
symlinkfolder "_Sega Tetris"
symlinkfolder "_Time Scanner"
symlinkfolder "_Wonder Boy 3"




exit 0