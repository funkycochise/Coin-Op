 #!/bin/bash  

RegSourceRoot=/media/fat/_Arcade
AltSourceRoot=/media/fat/_Arcade/_alternatives

function create {
newFolder=$1
#echo "   creating ${newFolder}"
mkdir -p "${newFolder}"
}

function symlinkfolder {

echo "   1 : $1" >/dev/null
echo "   2 : $2" >/dev/null
if ([ -z "$2" ]); then 
   echo "no rename, linking folder" >/dev/null
   ln -s "$AltSourceRoot/$1"  "$OutputRoot/$MainDir/$1"
else
   #rename alternate folder if existing
   echo "renaming detected" >/dev/null
   if [ -d "$AltSourceRoot/$2" ]; then
      echo "renamed folder exists, linking" >/dev/null
   else
      if [ -d "$AltSourceRoot/$1" ]; then
         echo "$AltSourceRoot/$1 exists, renaming to $AltSourceRoot/$2" >/dev/null
         mv "$AltSourceRoot/$1" "$AltSourceRoot/$2"
      fi
   fi
   ln -s "$AltSourceRoot/$2"  "$OutputRoot/$MainDir/$2"
fi
}


function copyfile {
echo "copying $RegSourceRoot/$1 to $AltSourceRoot/$2" >/dev/null

if [ -d "$AltSourceRoot/$2" ]; then
   echo "$AltSourceRoot/$2 exists" >/dev/null
else
   echo "   $AltSourceRoot/$2 doesn't exist" >/dev/null
   mkdir -p "$AltSourceRoot/$2"
fi
cp "$RegSourceRoot/$1" "$AltSourceRoot/$2"
}
