 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Upl"

cd $OutputRoot

create "$MainDir"

copyfile "Ninjakun.mra" "_Ninjakun Majou no Bouken"
copyfile "Penguin-Kun_Wars.mra" "_Penguin-Kun_Wars"
copyfile "Penguin-Kun_Wars_Japan.mra" "_Penguin-Kun_Wars"

symlinkfolder "_Ninjakun Majou no Bouken"
symlinkfolder "_Penguin-Kun_Wars"


exit 0