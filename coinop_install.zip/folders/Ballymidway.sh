 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Bally-Midway"

cd $OutputRoot

create "$MainDir"

copyfile "Demolition Derby.mra" "_Demolition Derby"
copyfile "Discs of Tron.mra" "_Discs of Tron"
copyfile "Domino Man.mra" "_Domino Man"
copyfile "Extra Bases.mra" "_Extra Bases"
copyfile "Gorf - Program 1.mra" "_Gorf"
copyfile "Gorf - Speech.mra" "_Gorf"
copyfile "Gorf.mra" "_Gorf"
copyfile "Journey.mra" "_Journey"
copyfile "Kick.mra" "_Kick"
copyfile "Kick-Man.mra" "_Kick-Man"
copyfile "Kozmik Kroozr.mra" "_Kozmik Kroozr"
copyfile "Max RPM.mra" "_Max RPM"
copyfile "Ms. Pacman.mra" "_Ms. Pacman"
copyfile "Pac-Man (Midway).mra" "_Pacman"
copyfile "Pacman Plus.mra" "_Pacman Plus"
copyfile "Power Drive.mra" "_Power Drive"
copyfile "Rampage.mra" "_Rampage"
copyfile "Robby Roto.mra" "_Robby Roto"
copyfile "The Adventures of Robby Roto!.mra" "_Robby Roto"
copyfile "Sarge.mra" "_Sarge"
copyfile "Satans Hollow.mra" "_Satan's Hollow"
copyfile "Seawolf II.mra" "_Seawolf II"
copyfile "Solar Fox.mra" "_Solar Fox"
copyfile "Space Invaders.mra" "_Space Invaders"
copyfile "Space Zap.mra" "_Space Zap"
copyfile "Star Guards.mra" "_Star Guards"
copyfile "Tapper.mra" "_Tapper"
copyfile "Timber.mra" "_Timber"
copyfile "Tron.mra" "_Tron"
copyfile "Two Tigers.mra" "_Two Tigers"
copyfile "Wacko.mra" "_Wacko"
copyfile "Wizard of Wor - Speech.mra" "_Wizard of Wor"
copyfile "Wizard of Wor.mra" "_Wizard of Wor"

symlinkfolder "_Burning Rubber"
symlinkfolder "_Demolition Derby"
symlinkfolder "_Discs of Tron"
symlinkfolder "_Domino Man"
symlinkfolder "_Extra Bases"
symlinkfolder "_Galaga"
symlinkfolder "_Galaxian"
symlinkfolder "_Gorf"
symlinkfolder "_Journey"
symlinkfolder "_Kick"
symlinkfolder "_Kick-Man"
symlinkfolder "_Kozmik Kroozr"
symlinkfolder "_Max RPM"
symlinkfolder "_Ms. Pacman"
symlinkfolder "_Pac-Man"
symlinkfolder "_Pacman Plus"
symlinkfolder "_Power Drive"
symlinkfolder "_Rampage"
symlinkfolder "_Robby Roto"
symlinkfolder "_Sarge"
symlinkfolder "_Satan's Hollow"
symlinkfolder "_Seawolf II"
symlinkfolder "_Solar Fox"
symlinkfolder "_Space Invaders"
symlinkfolder "_Space Zap"
symlinkfolder "_Star Guards"
symlinkfolder "_Tapper"
symlinkfolder "_Timber"
symlinkfolder "_Tron"
symlinkfolder "_Two Tigers"
symlinkfolder "_Wacko"
symlinkfolder "_Wizard of Wor"

exit 0