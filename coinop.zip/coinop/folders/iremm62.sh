 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Irem M62 Hardware"

cd $OutputRoot

create "$MainDir"

copyfile "Battle Road.mra" "_Battle Road"
copyfile "Horizon (Irem).mra" "_Horizon"
copyfile "Horizon.mra" "_Horizon"
copyfile "Kid Niki - Radical Ninja.mra" "_Kid Niki - Radical Ninja"
copyfile "Kid Niki - Radical Ninja (W).mra" "_Kid Niki - Radical Ninja"
copyfile "Kung-Fu Master.mra" "_Kung-Fu Master"
copyfile "Kung-Fu Master (W).mra" "_Kung-Fu Master"
copyfile "Spartan-X.mra" "_Kung-Fu Master"
copyfile "Lode Runner III - The Golden Labyrinth.mra" "_Lode Runner III"
copyfile "Lode Runner II - The Bungeling Strikes Back.mra" "_Lode Runner II"
copyfile "Lode Runner IV - Teikoku Karano Dasshutsu (JP).mra" "_Lode Runner IV"
copyfile "Lode Runner IV - Teikoku Karano Dasshutsu.mra" "_Lode Runner IV"
copyfile "Lode Runner.mra" "_Lode Runner" "_Lode Runner"
copyfile "Lode Runner (Set 1).mra" "_Lode Runner"
copyfile "Kaiketsu Yancha Maru.mra" "_Kid Niki - Radical Ninja"
copyfile "Spelunker II - 23 no Kagi (JP).mra" "_Spelunker II"
copyfile "Spelunker II - 23 no Kagi.mra" "_Spelunker II"
copyfile "Spelunker.mra" "_Spelunker"
copyfile "Youjyuden (JP).mra" "_Youjyuden"
copyfile "Youjyuden.mra" "_Youjyuden"

symlinkfolder "_Battle Road"
symlinkfolder "_Horizon"
symlinkfolder "_Kid Niki - Radical Ninja"
symlinkfolder "_Kung-Fu Master"
symlinkfolder "_Lode Runner III"
symlinkfolder "_Lode Runner II"
symlinkfolder "_Lode Runner IV"
symlinkfolder "_Lode Runner"
symlinkfolder "_Spelunker II"
symlinkfolder "_Spelunker"
symlinkfolder "_Youjyuden"




exit 0