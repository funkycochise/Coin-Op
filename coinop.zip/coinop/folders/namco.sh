 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Namco"

cd $OutputRoot

create "$MainDir"

copyfile "Dig Dug (Rev 2).mra" "_Dig Dug"
copyfile "Dig Dug II (New Ver).mra" "_Dig Dug II"
copyfile "The Tower of Druaga.mra" "_The Tower of Druaga"
copyfile "Galaga (Midway, Set 1).mra" "_Galaga"
copyfile "Galaga.mra" "_Galaga"
copyfile "Gatsbee.mra" "_Galaga"
copyfile "Galaxian (Namco, Set 1).mra" "_Galaxian"
copyfile "Gaplus (GP2 Rev B).mra" "_Gaplus"
copyfile "Galaga 3 (GP3 Rev D).mra" "_Gaplus"
copyfile "Grobda (W, New Ver.).mra" "_Grobda"
copyfile "Grobda.mra" "_Grobda"
copyfile "Grobda (New Ver.).mra" "_Grobda"
copyfile "King And Balloon.mra" "_King And Balloon"
copyfile "Mappy.mra" "_Mappy"
copyfile "Motos.mra" "_Motos"
copyfile "Ms. Pac-Man.mra" "_Ms.Pacman"
copyfile "New Rally-X.mra" "_RallyX"
copyfile "Pac & Pal.mra" "_Pac & Pal"
copyfile "Pac-Man & Chomp Chomp.mra" "_Pac & Pal"
copyfile "Puck Man (Japan set 1).mra" "_Pacman"
copyfile "Rally-X.mra" "_RallyX"
copyfile "Rally-X (32k Ver).mra" "_RallyX"
copyfile "Super Pac-Man.mra" "_Super Pacman"
copyfile "Xevious.mra" "_Xevious"

symlinkfolder "_Dig Dug"
symlinkfolder "_Dig Dug II"
symlinkfolder "_Galaga"
symlinkfolder "_Galaxian"
symlinkfolder "_Gaplus"
symlinkfolder "_Grobda"
symlinkfolder "_King And Balloon"
symlinkfolder "_Mappy"
symlinkfolder "_Motos"
symlinkfolder "_Ms.Pacman"
symlinkfolder "_Pac & Pal"
symlinkfolder "_Pacman"
symlinkfolder "_RallyX"
symlinkfolder "_The Tower of Druaga"
symlinkfolder "_Super Pacman"
symlinkfolder "_Xevious"

exit 0