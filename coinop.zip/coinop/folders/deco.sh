 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Upl"

cd $OutputRoot

create "$MainDir"

copyfile "Bump 'n' Jump.mra" "_Burning Rubber"
copyfile "Burnin' Rubber.mra" "_Burning Rubber"
copyfile "Burger Time.mra" "_Burger Time"
copyfile "Burger Time (Set 1).mra" "_Burger Time"

symlinkfolder "_Burning Rubber"
symlinkfolder "_Burger Time"

exit 0