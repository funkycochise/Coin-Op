 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Taito"

cd $OutputRoot

create "$MainDir"

copyfile "Arkanoid (Japan).mra" "_Arkanoid"
copyfile "Arkanoid (JP).mra" "_Arkanoid"
copyfile "Arkanoid.mra" "_Arkanoid"
copyfile "Arkanoid (Unl. lives) [hb].mra" "_Arkanoid"
copyfile "Arkanoid (US).mra" "_Arkanoid"
copyfile "Arkanoid (W).mra" "_Arkanoid"
copyfile "Arkanoid (World).mra" "_Arkanoid"
copyfile "Balloon Bomber.mra" "_Balloon Bomber"
copyfile "Bubble Bobble (Japan, Ver 0.1).mra" "_Bubble Bobble"
copyfile "Bubble Bobble.mra" "_Bubble Bobble"
copyfile "Colony 7.mra" "_Colony7"
copyfile "Colony 7 (Set 1).mra" "_Colony7"
copyfile "Crazy Balloon.mra" "_Crazy Balloon"
copyfile "Lunar Rescue.mra" "_Lunar Rescue"
copyfile "Lupin III.mra" "_Lupin III"
copyfile "Lupin III (Set 2).mra" "_Lupin III"
copyfile "Space Chaser.mra" "_Space Chaser"
copyfile "Space Invaders.mra" "_Space Invaders"
copyfile "Space Invaders II (Midway, cocktail).mra" "_Space Invaders Part II"
copyfile "Space Invaders Part II.mra" "_Space Invaders Part II"
copyfile "Space Invaders Part II (Taito, Bigger ROMs).mra" "_Space Invaders Part II"
copyfile "Tokio - Scramble Formation (bootleg).mra" "_Tokio" 


symlinkfolder "_Arkanoid"
symlinkfolder "_Balloon Bomber"
symlinkfolder "_Bubble Bobble"
symlinkfolder "_Colony7"
symlinkfolder "_Crazy Balloon"
symlinkfolder "_Lunar Rescue"
symlinkfolder "_Lupin III"
symlinkfolder "_Space Chaser"
symlinkfolder "_Space Invaders"
symlinkfolder "_Space Invaders Part II"
symlinkfolder "_Tokio"


exit 0