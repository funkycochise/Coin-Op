 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Capcom"

cd $OutputRoot

create "$MainDir"

copyfile  "1942.mra" "_1942"
copyfile  "1943 Kai Midway Kaisen.mra" "_1943"
copyfile  "1943 Midway Kaisen.mra" "_1943"
copyfile  "1943 The Battle of Midway Mark II.mra" "_1943"
copyfile  "1943 The Battle of Midway.mra" "_1943"
copyfile  "Bionic Commando.mra" "_Bionic Commando"
copyfile  "Black Tiger.mra" "_Black Tiger"
copyfile  "Commando.mra" "_Commando"
copyfile  "F-1 Dream.mra" "_F-1 Dream"
copyfile  "Ghosts'n Goblins.mra" "_Ghosts'n Goblins"
copyfile  "Gun Smoke.mra" "_Gun.Smoke"
copyfile  "Legendary Wings.mra" "_Legendary Wings"
copyfile  "Pirate Ship Higemaru.mra" "_Pirate Ship Higemaru"
copyfile  "SectionZ.mra" "_SectionZ"
copyfile  "Side Arms - Hyper Dyne (World, 861129).mra" "_Side Arms"
copyfile  "Street Fighter (US, set 1).mra" "_Street Fighter"
copyfile  "The Speed Rumbler (set 1).mra" "_The Speed Rumbler"
copyfile  "Tiger Road.mra" "_Tiger Road"
copyfile  "Trojan (Romstar).mra" "_Trojan"
copyfile  "Vulgus.mra" "_Vulgus"
copyfile  "Exed Exes.mra" "_Exed Exes"
copyfile  "Savage Bees.mra" "_Exed Exes"

symlinkfolder "_1942"
symlinkfolder "_1943"
symlinkfolder "_Bionic Commando"
symlinkfolder "_Black Tiger"
symlinkfolder "_Commando"
symlinkfolder "_F-1 Dream"
symlinkfolder "_Ghosts'n Goblins"
symlinkfolder "_Gun.Smoke"
symlinkfolder "_Legendary Wings"
symlinkfolder "_Pirate Ship Higemaru"
symlinkfolder "_SectionZ"
symlinkfolder "_Side Arms"
symlinkfolder "_The Speed Rumbler"
symlinkfolder "_Street Fighter"
symlinkfolder "_Tiger Road"
symlinkfolder "_Trojan"
symlinkfolder "_Vulgus"
symlinkfolder "_Exed Exes"




exit 0