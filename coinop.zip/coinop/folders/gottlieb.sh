 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Gottlieb"

cd $OutputRoot

create "$MainDir"

copyfile "Curve Ball.mra" "_Curve Ball"
copyfile "Insector.mra" "_Insector"
copyfile "Mad Planets.mra" "_Mad Planets"
copyfile "QBert Qubes.mra" "_QBert Qubes"
copyfile "QBert.mra" "_QBert"
copyfile "Tylz.mra" "_Tylz"

symlinkfolder "_Curve Ball"
symlinkfolder "_Insector"
symlinkfolder "_Mad Planets"
symlinkfolder "_QBert Qubes"
symlinkfolder "_QBert"
symlinkfolder "_Tylz"

exit 0