 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Williams"

cd $OutputRoot

create "$MainDir"

copyfile "Alien Arena.mra" "_Alien Arena"
copyfile "Alien Arena (Stargate upgrade).mra" "_Alien Arena"
copyfile "Bubbles.mra" "_Bubbles"
copyfile "Colony 7.mra" "_Colony7"
copyfile "Colony 7 (Set 1).mra" "_Colony7"
copyfile "Defender.mra" "_Defender"
copyfile "Defender (Red Label).mra" "_Defender"
copyfile "Jin.mra" "_Jin"
copyfile "Joust.mra" "_Joust"
copyfile "Mayday.mra" "_Mayday"
copyfile "Mayday (Set 1).mra" "_Mayday"
copyfile "Playball.mra" "_Playball"
copyfile "Robotron 2084.mra" "_Robotron"
copyfile "Sinistar.mra" "_Sinistar"
copyfile "Splat!.mra" "_Splat"
copyfile "Stargate.mra" "_Stargate"

symlinkfolder "_Alien Arena"
symlinkfolder "_Bubbles"
symlinkfolder "_Colony7"
symlinkfolder "_Defender"
symlinkfolder "_Jin"
symlinkfolder "_Joust"
symlinkfolder "_Mayday"
symlinkfolder "_Playball"
symlinkfolder "_Robotron"
symlinkfolder "_Sinistar"
symlinkfolder "_Splat"
symlinkfolder "_Stargate"


exit 0