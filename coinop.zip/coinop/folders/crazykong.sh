 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Crazy Kong"

cd $OutputRoot

#create "$MainDir"

copyfile "Big Kong.mra" "_Crazy Kong"
copyfile "Crazy Kong (Orca bootleg).mra" "_Crazy Kong"
copyfile "Crazy Kong Part II.mra" "_Crazy Kong"
copyfile "Donkey Kong (Spanish Crazy Kong bootleg).mra" "_Crazy Kong"

symlinkfolder "_Crazy Kong"


exit 0