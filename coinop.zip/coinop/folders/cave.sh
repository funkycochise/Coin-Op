 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Cave"

cd $OutputRoot

#create "$MainDir"

copyfile "Dangun Feveron.mra" "_Cave68K"
copyfile "DoDonPachi (Arrange).mra" "_Cave68K"
copyfile "DoDonPachi (Japan).mra" "_Cave68K"
copyfile "DoDonPachi (Japan, No Warn).mra" "_Cave68K"
copyfile "DoDonPachi (Japan, Trainer).mra" "_Cave68K"
copyfile "DoDonPachi.mra" "_Cave68K"
copyfile "ESP Ra.De..mra" "_Cave68K"
copyfile "Fever SOS.mra" "_Cave68K"
copyfile "Puzzle Uo Poko.mra" "_Cave68K"

symlinkfolder "_Cave68K"

exit 0