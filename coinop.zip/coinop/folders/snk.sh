 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_SNK"

cd $OutputRoot

#create "$MainDir"

rm /media/fat/_Arcade/cores/Neogeo* 2> /dev/null
cp /media/fat/_Console/NeoGeo* /media/fat/_Arcade/cores/

copyfile "NeoGeo.mra" "_SNK"

symlinkfolder "_SNK"

exit 0