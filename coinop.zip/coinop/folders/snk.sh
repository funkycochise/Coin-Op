 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_SNK"

cd $OutputRoot

#create "$MainDir"

copyfile "NeoGeo.mra" "_SNK"

symlinkfolder "_SNK"

exit 0