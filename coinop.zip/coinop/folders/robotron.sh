 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Robotron"

cd $OutputRoot

#create "$MainDir"
copyfile "Alien Arena.mra" "_Robotron"
copyfile "Bubbles.mra" "_Robotron"
copyfile "Joust.mra" "_Robotron"
copyfile "Playball.mra" "_Robotron"
copyfile "Robotron 2084.mra" "_Robotron"
copyfile "Sinistar.mra" "_Robotron"
copyfile "Splat!.mra" "_Robotron"
copyfile "Stargate.mra" "_Robotron"

symlinkfolder "_Robotron"

exit 0