 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-SystemE"

cd $OutputRoot

create "$MainDir"

copyfile "Astro Flash (Japan).mra" "_SystemE_Astro Flash"
copyfile "Fantasy Zone II - The Tears of Opa-Opa.mra" "_SystemE_Fantasy Zone 2"
copyfile "Hang On Jr.mra" "_SystemE_Hang On Jr"
copyfile "Opa Opa (Rev A, unprotected).mra" "_SystemE_Opa Opa"
copyfile "Opa Opa.mra" "_SystemE_Opa Opa"
copyfile "Riddle of Pythagoras (Japan).mra" "_SystemE_Riddle of Pythagoras"
copyfile "Slap Shooter.mra" "_SystemE_Slap Shooter"
copyfile "Tetris (Japan, System E).mra" "_SystemE_Tetris"

symlinkfolder "_SystemE_Astro Flash" "_Astro Flash"
symlinkfolder "_SystemE_Fantasy Zone 2" "_Fantasy Zone 2"
symlinkfolder "_SystemE_Hang On Jr" "_Hang On Jr"
symlinkfolder "_SystemE_Opa Opa" "_Opa Opa"
symlinkfolder "_SystemE_Riddle of Pythagoras" "_Riddle of Pythagoras"
symlinkfolder "_SystemE_Slap Shooter" "_Slap Shooter"
symlinkfolder "_SystemE_Tetris" "_Tetris"

exit 0