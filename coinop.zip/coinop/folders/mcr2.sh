 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_MCR2"

cd $OutputRoot

create "$MainDir"

copyfile "Domino Man.mra" "_Domino Man"
copyfile "Kozmik Krooz'r.mra" "_Kozmik Kroozr"
copyfile "Satans Hollow.mra" "_Satan's Hollow"
copyfile "Satan's Hollow (Set 1).mra" "_Satan's Hollow"
copyfile "Tron.mra" "_Tron"
copyfile "Two Tigers.mra" "_Two Tigers"
copyfile "Two Tigers (Tron Conversion).mra" "_Two Tigers"
copyfile "Wacko.mra" "_Wacko"

symlinkfolder "_Domino Man"
symlinkfolder "_Kozmik Kroozr"
symlinkfolder "_Satan's Hollow"
symlinkfolder "_Tron"
symlinkfolder "_Two Tigers"
symlinkfolder "_Wacko"

exit 0