 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_MCR3Mono"

cd $OutputRoot

create "$MainDir"

copyfile "Demolition Derby.mra" "_Demolition Derby"
copyfile "Demolition Derby (MCR-3 Mono Board Version).mra" "_Demolition Derby"
copyfile "Max RPM.mra" "_Max RPM"
copyfile "Max RPM (v2).mra" "_Max RPM"
copyfile "Power Drive.mra" "_Power Drive"
copyfile "Rampage.mra" "_Rampage"
copyfile "Rampage (Rev 3, 860827).mra" "_Rampage"
copyfile "Sarge.mra" "_Sarge"
copyfile "Star Guards.mra" "_Star Guards"

symlinkfolder "_Demolition Derby"
symlinkfolder "_Max RPM"
symlinkfolder "_Power Drive"
symlinkfolder "_Rampage"
symlinkfolder "_Sarge"
symlinkfolder "_Star Guards"

exit 0