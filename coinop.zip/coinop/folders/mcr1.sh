 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_MCR1"

cd $OutputRoot

create "$MainDir"

copyfile "Kick.mra" "_Kick"
copyfile "Kick-Man.mra" "_Kick-Man"
copyfile "Solar Fox.mra" "_Solar Fox"

symlinkfolder "_Kick"
symlinkfolder "_Kick-Man"
symlinkfolder "_Solar Fox"

exit 0