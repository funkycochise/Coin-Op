 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-System1-2"

cd $OutputRoot

create "$MainDir"

copyfile "4-D Warriors.mra" "_4D Warriors"
copyfile "4D Warriors (315-5162).mra" "_4D Warriors"
copyfile "Block Gal.mra" "_Block Gal"
copyfile "Bullfight.mra" "_Bullfight"
copyfile "Brain.mra" "_Brain"
copyfile "Choplifter (unprotected).mra" "_Choplifter"
copyfile "Flicky.mra" "_Flicky"
copyfile "Gardia (317-0006).mra" "_Gardia"
copyfile "Heavy Metal (315-5135).mra" "_Heavy Metal"
copyfile "I'm Sorry.mra" "_I'm sorry"
copyfile "Mister Viking (315-5041).mra" "_Mister Viking"
copyfile "Mister Viking (315-5041, Japan).mra" "_Mister Viking"
copyfile "Noboranka (bootleg).mra" "_Noboranka"
copyfile "My Hero.mra" "_My Hero"
copyfile "Pitfall II.mra" "_Pitfall II"
copyfile "Rafflesia.mra" "_Rafflesia"
copyfile "Rafflesia (315-5162).mra" "_Rafflesia"
copyfile "Regulus.mra" "_Regulus"
copyfile "Sega Ninja.mra" "_Sega Ninja"
copyfile "Spatter.mra" "_Spatter"
copyfile "Star Jacker.mra" "_Star Jacker"
copyfile "Star Jacker (alt).mra" "_Star Jacker"
copyfile "Swat.mra" "_Swat"
copyfile "TeddyBoy Blues.mra" "_TeddyBoy Blues"
copyfile "Up'n Down.mra" "_Up'n Down"
copyfile "Water Match.mra" "_Water Match"
copyfile "Water Match (315-5064).mra" "_Water Match"
copyfile "Wonder Boy.mra" "_Wonder Boy"
copyfile "Wonder Boy (Set 1, 315-5177).mra" "_Wonder Boy"
copyfile "UFO Senshi Youko Chan (bootleg).mra" "_UFO Senshi Youko Chan"
copyfile "Wonder Boy in Monster Land.mra" "_Wonder Boy in Monster Land"
copyfile "Toki no Senshi - Chrono Soldier.mra" "_Toki no Senshi - Chrono Soldier"


symlinkfolder "_4D Warriors"
symlinkfolder "_Block Gal"
symlinkfolder "_Brain"
symlinkfolder "_Bullfight"
symlinkfolder "_Choplifter"
symlinkfolder "_Flicky"
symlinkfolder "_Gardia"
symlinkfolder "_Heavy Metal"
symlinkfolder "_I'm sorry"
symlinkfolder "_Mister Viking"
symlinkfolder "_Noboranka"
symlinkfolder "_My Hero"
symlinkfolder "_Pitfall II"
symlinkfolder "_Rafflesia"
symlinkfolder "_Regulus"
symlinkfolder "_Sega Ninja"
symlinkfolder "_Spatter"
symlinkfolder "_Star Jacker"
symlinkfolder "_Swat"
symlinkfolder "_TeddyBoy Blues"
symlinkfolder "_Up'n Down"
symlinkfolder "_Water Match"
symlinkfolder "_Wonder Boy"
symlinkfolder "_UFO Senshi Youko Chan"
symlinkfolder "_Wonder Boy in Monster Land"
symlinkfolder "_Toki no Senshi - Chrono Soldier"

exit 0