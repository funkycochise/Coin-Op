 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Ladybug"

cd $OutputRoot

create "$MainDir"

copyfile "Cosmic Avenger.mra" "_Cosmic Avenger"
copyfile "Dorodon.mra" "_Dorodon"
copyfile "Lady Bug.mra" "_Lady Bug"
copyfile "Snap Jack.mra" "_Snap Jack"

symlinkfolder "_Cosmic Avenger"
symlinkfolder "_Dorodon"
symlinkfolder "_Lady Bug"
symlinkfolder "_Snap Jack"

exit 0