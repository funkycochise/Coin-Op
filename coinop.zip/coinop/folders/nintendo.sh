 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Nintendo"

cd $OutputRoot

create "$MainDir"

copyfile "Donkey Kong.mra" "_Donkey Kong"
copyfile "Donkey Kong (Spanish Crazy Kong bootleg).mra" "_Donkey Kong"
copyfile "Donkey Kong (US, Set 1).mra" "_Donkey Kong"
copyfile "Donkey Kong Junior.mra" "_Donkey Kong Junior"
copyfile "Donkey Kong Junior (US, Set F-2).mra" "_Donkey Kong Junior"
copyfile "Donkey Kong 3.mra" "_Donkey Kong 3"
copyfile "Donkey Kong 3 (US).mra" "_Donkey Kong 3"
copyfile "Mario Bros.mra" "_Mario Bros"
copyfile "Mario Bros. (US, Rev G).mra" "_Mario Bros"
copyfile "Popeye.mra" "_Popeye"
copyfile "Radar Scope.mra" "_Radar Scope"
copyfile "Sky Skipper.mra" "_Sky Skipper"

symlinkfolder "_Donkey Kong"
symlinkfolder "_Donkey Kong Junior"
symlinkfolder "_Donkey Kong 3"
symlinkfolder "_Mario Bros"
symlinkfolder "_Popeye"
symlinkfolder "_Radar Scope"
symlinkfolder "_Sky Skipper"


exit 0