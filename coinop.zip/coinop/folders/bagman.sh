 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Bagman"

cd $OutputRoot

create "$MainDir"

copyfile "Bagman.mra" "_Bagman"
copyfile "Botanic.mra" "_Botanic"
copyfile "Botanic (English, Spanish, Set 1).mra" "_Botanic"
copyfile "Pickin'.mra" "_Pickin'"
copyfile "Squash.mra" "_Squash"
copyfile "Super Bagman.mra" "_Super Bagman"

symlinkfolder "_Bagman"
symlinkfolder "_Botanic"
symlinkfolder "_Pickin'"
symlinkfolder "_Squash"
symlinkfolder "_Super Bagman"


exit 0