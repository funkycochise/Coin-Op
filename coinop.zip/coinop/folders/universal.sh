 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Universal"

cd $OutputRoot

create "$MainDir"

copyfile "Galaxy Wars.mra" "_Galaxy Wars"
copyfile "Galaxy Wars (Universal, Set 1).mra" "_Galaxy Wars"
copyfile "Lady Bug.mra" "_Lady Bug"
copyfile "Mr. Do! Fixed.mra" "_Mr. Do!"
copyfile "Mr. Do!.mra" "_Mr. Do!"

symlinkfolder "_Galaxy Wars"
symlinkfolder "_Lady Bug"
symlinkfolder "_Mr. Do!"

exit 0