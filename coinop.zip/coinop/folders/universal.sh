 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Universal"

cd $OutputRoot

create "$MainDir"

copyfile "Galaxy Wars.mra" "_Galaxy Wars"
copyfile "Galaxy Wars (Universal, Set 1).mra" "_Galaxy Wars"
copyfile "Lady Bug.mra" "_Lady Bug"
copyfile "Mr. Do! Fixed.mra" "_Mr. Do!"
copyfile "Mr. Do!.mra" "_Mr. Do!"
copyfile "Space Panic.mra" "_Space Panic"
copyfile "Magical Spot.mra" "_Magical Spot"
copyfile "Cosmic Alien.mra" "_Cosmic Alien"


symlinkfolder "_Galaxy Wars"
symlinkfolder "_Lady Bug"
symlinkfolder "_Mr. Do!"
symlinkfolder "_Space Panic"
symlinkfolder "_Magical Spot"
symlinkfolder "_Cosmic Alien"

exit 0