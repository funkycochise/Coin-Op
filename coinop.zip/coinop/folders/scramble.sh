 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Scramble"

cd $OutputRoot

#create "$MainDir"

copyfile "Amidar (Scramble).mra" "_Scramble"
copyfile "Anteater.mra" "_Scramble" 
copyfile "Armored Car.mra" "_Scramble" 
copyfile "Battle of Atlantis.mra" "_Scramble" 
copyfile "Calipso.mra" "_Scramble" 
copyfile "Dark Planet.mra" "_Scramble" 
copyfile "Frogger.mra" "_Scramble"
copyfile "Lost Tomb.mra" "_Scramble" 
copyfile "Mars.mra" "_Scramble"
copyfile "Mighty Monkey (Scramble Hardware) [bl].mra" "_Scramble"
copyfile "Minefield.mra" "_Scramble"
copyfile "Moon War.mra" "_Scramble" 
copyfile "Rescue.mra" "_Scramble"
copyfile "Scramble.mra" "_Scramble" 
copyfile "Speed Coin.mra" "_Scramble"
copyfile "Strategy X.mra" "_Scramble"
copyfile "Super Cobra.mra" "_Scramble" 
copyfile "Tazz-Mania.mra" "_Scramble"
copyfile "The End.mra" "_Scramble" 
copyfile "Turtles.mra" "_Scramble"

symlinkfolder "_Scramble"

exit 0