 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_MCR3"

cd $OutputRoot

create "$MainDir"

copyfile "Discs of Tron.mra" "_Disc of Tron"
copyfile "Journey.mra" "_Journey"
copyfile "Tapper.mra" "_Tapper"
copyfile "Tapper (Budweiser, 840127).mra" "_Tapper"
copyfile "Timber.mra" "_Timber"

symlinkfolder "_Disc of Tron"
symlinkfolder "_Journey"
symlinkfolder "_Tapper"
symlinkfolder "_Timber"

exit 0