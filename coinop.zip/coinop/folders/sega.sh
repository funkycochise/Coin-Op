 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega"

cd $OutputRoot

create "$MainDir"

copyfile "Future Spy.mra" "_Future Spy"
copyfile "Pengo (Set 1, Rev C).mra" "_Pengo"
copyfile "Super Zaxxon.mra" "_Super Zaxxon"
copyfile "zaxxon.mra" "_Zaxxon"

symlinkfolder "_Future Spy"
symlinkfolder "_Pengo"
symlinkfolder "_Super Zaxxon"
symlinkfolder "_Zaxxon"

exit 0