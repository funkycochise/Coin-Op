 #!/bin/bash  

source ./folders/functions.sh

OutputRoot=$1

MainDir="_CPS1.5"

cd $OutputRoot

create "$MainDir"

copyfile  "Cadillacs and Dinosaurs (World 930201).mra" "_Cadillacs and Dinosaurs"
copyfile  "Muscle Bomber Duo Ultimate Team Battle (World 931206).mra" "_Muscle Bomber Duo"
copyfile  "Saturday Night Slam Masters (World 930713).mra" "_Saturday Night Slam Masters"
copyfile  "The Punisher (World 930422).mra" "_The Punisher"
copyfile  "Warriors of Fate (World 921031).mra" "_Warriors of Fate"

symlinkfolder "_Cadillacs and Dinosaurs"
symlinkfolder "_Muscle Bomber Duo"
symlinkfolder "_Saturday Night Slam Masters"
symlinkfolder "_The Punisher"
symlinkfolder "_Warriors of Fate"

exit 0