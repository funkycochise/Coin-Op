 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Upl"

cd $OutputRoot

create "$MainDir"

copyfile "Ninjakun.mra" "_Ninjakun Majou no Bouken"
copyfile "Penguin-Kun Wars.mra" "_Penguin-Kun Wars"
copyfile "Penguin-Kun Wars (Japan).mra" "_Penguin-Kun Wars"

symlinkfolder "_Ninjakun Majou no Bouken"
symlinkfolder "_Penguin-Kun Wars"


exit 0