 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Space Invaders"

cd $OutputRoot

#create "$MainDir"

copyfile "280Z-ZZAP.mra" "_Space Invaders"
copyfile "Amazing Maze.mra" "_Space Invaders"
copyfile "Attack Force.mra" "_Space Invaders"
copyfile "Balloon Bomber.mra" "_Space Invaders"
copyfile "Blue Shark.mra" "_Space Invaders"
copyfile "Boot Hill.mra" "_Space Invaders"
copyfile "Clowns.mra" "_Space Invaders"
copyfile "Cosmo.mra" "_Space Invaders"
copyfile "Galaxy Wars.mra" "_Space Invaders"
copyfile "Gun Fight.mra" "_Space Invaders"
copyfile "Laguna Racer.mra" "_Space Invaders"
copyfile "Lunar Rescue.mra" "_Space Invaders"
copyfile "Lupin III.mra" "_Space Invaders"
copyfile "Sea Wolf.mra" "_Space Invaders"
copyfile "Shuffleboard.mra" "_Space Invaders"
copyfile "Shuttle Invader.mra" "_Space Invaders"
copyfile "Space Chaser.mra" "_Space Invaders"
copyfile "Space Encounters.mra" "_Space Invaders"
copyfile "Space Invaders II (Midway, cocktail).mra" "_Space Invaders"
copyfile "Space Invaders Part II.mra" "_Space Invaders"
copyfile "Space Invaders.mra" "_Space Invaders"
copyfile "Vortex.mra" "_Space Invaders"

symlinkfolder "_Space Invaders"
