 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_MCR3Scroll"

cd $OutputRoot

create "$MainDir"

copyfile "Crater Raider.mra" "_Crater Raider"
copyfile "Spy Hunter.mra" "_Spy Hunter"
copyfile "Turbo Tag.mra" "_Turbo Tag"
copyfile "Turbo Tag (Prototype).mra" "_Turbo Tag"

symlinkfolder "_Crater Raider"
symlinkfolder "_Spy Hunter"
symlinkfolder "_Turbo Tag"

exit 0