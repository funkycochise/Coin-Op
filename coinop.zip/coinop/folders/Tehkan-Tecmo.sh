 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Tehkan-Tecmo"

cd $OutputRoot

create "$MainDir"

copyfile "Bomb Jack.mra" "_Bomb Jack"
copyfile "Gemini Wing.mra" "_Gemini Wing"
copyfile "Pleiads (Centuri).mra" "_Pleiads"
copyfile "Pleiads.mra" "_Pleiads"
copyfile "Pleiads (Tehkan).mra" "_Pleiads"
copyfile "Rygar.mra" "_Rygar"
copyfile "Silkworm.mra" "_Silkworm"
copyfile "Solomon's Key.mra" "_Solomons Key"

symlinkfolder "_Bomb Jack"
symlinkfolder "_Gemini Wing"
symlinkfolder "_Pleiads"
symlinkfolder "_Rygar.mra"
symlinkfolder "_Silkworm"
symlinkfolder "_Solomons Key"

exit 0