 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Atari"

cd $OutputRoot

create "$MainDir"
symlinkfolder "_Tetris" "_Atari Tetris"


exit 0