 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

MainDir="_Sega-System16"

cd $OutputRoot

create "$MainDir"

copyfile "Action Fighter (World, S16A) [FD1089A 317-0018].mra" "_Action Fighter"
copyfile "Alex Kidd The Lost Stars (Set 2, World, S16A) [No Protection].mra" "_Alex Kidd"
copyfile "Alien Syndrome (set 4, System 16B, unprotected).mra" "_Alien Syndrome"
copyfile "Aurail (set 3, US) (unprotected).mra" "_Aurail"
copyfile "Body Slam (World, S16) [8751 317-0015].mra" "_Body Slam"
copyfile "Bullet (FD1094 317-0041).mra" "_Bullet"
copyfile "Dynamite Dux (set 3, World) (FD1094 317-0096).mra" "_Dynamite Dux"
copyfile "Fantasy Zone (Rev A, World, S16A) [No Protection].mra" "_Fantasy Zone"
copyfile "Flash Point (set 2, Japan) (FD1094 317-0127A).mra" "_Flash Point"
copyfile "Passing Shot (World, 2 Players) (FD1094 317-0080).mra" "_Passing Shot"
copyfile "Quartet 2 (World, S16A) [No Protection].mra" "_Quartet"
copyfile "RyuKyu (Rev A, Japan) (FD1094 317-5023A).mra" "_RyuKyu"
copyfile "Shinobi (Set 6, World, S16A) [No Protection].mra" "_Shinobi"
copyfile "Tetris (Set 4, Japan, S16A) [FD1094 317-0093].mra" "_Tetris"
copyfile "Time Scanner (set 2, System 16B).mra" "_Time Scanner"

symlinkfolder "_Action Fighter"
symlinkfolder "_Alex Kidd"
symlinkfolder "_Alien Syndrome"
symlinkfolder "_Aurail"
symlinkfolder "_Body Slam"
symlinkfolder "_Bullet"
symlinkfolder "_Dynamite Dux"
symlinkfolder "_Fantasy Zone"
symlinkfolder "_Flash Point" 
symlinkfolder "_Passing Shot"
symlinkfolder "_Quartet"
symlinkfolder "_RyuKyu"
symlinkfolder "_Shinobi"
symlinkfolder "_Tetris"
symlinkfolder "_Time Scanner"
symlinkfolder "_Wonder Boy 3"
symlinkfolder "_Altered Beast"
symlinkfolder "_Wrestle War"


exit 0