 #!/bin/bash  

source ./folders/functions.sh

echo "alt : $AltSourceRoot" >/dev/null

OutputRoot=$1

#echo "OutputRoot : $OutputRoot"

#MainDir="_Galaxian"

cd $OutputRoot

#create "$MainDir"

copyfile "Azurian Attack.mra" "_Galaxian"
copyfile "Black Hole.mra" "_Galaxian"
copyfile "Catacomb.mra" "_Galaxian"
copyfile "Clean Sweep.mra" "_Galaxian"
copyfile "Devil Fish.mra" "_Galaxian"
copyfile "Galaxian.mra" "_Galaxian"
copyfile "King And Balloon.mra" "_Galaxian"
copyfile "Lucky Today.mra" "_Galaxian"
copyfile "Moon Cresta.mra" "_Galaxian"
copyfile "Mr. Do Nightmare.mra" "_Galaxian"
copyfile "Omega.mra" "_Galaxian"
copyfile "Orbitron.mra" "_Galaxian"
copyfile "Pisces.mra" "_Galaxian"
copyfile "UniWar S.mra" "_Galaxian"
copyfile "Victory.mra" "_Galaxian"
copyfile "War of the Bugs.mra" "_Galaxian"

symlinkfolder "_Galaxian"

exit 0