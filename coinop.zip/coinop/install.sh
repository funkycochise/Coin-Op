#!/bin/bash

ZP="_Arcade_missing.zip"
TEMP=/media/fat/scripts/temp
ALT=/media/fat/_Arcade/_alternatives

mkdir $TEMP

cd $TEMP
rm -r _Arcade >/dev/null
rm $ZP  >/dev/null

curl https://raw.githubusercontent.com/funkycochise/Coin-Op/master/$ZP -O -k
unzip $ZP -d $TEMP
rm $ZP

#delete all _Tetris folders in alternatives
echo "Remove _Tetris references in alternatives folder"
rm -r "$ALT/_Tetris" >/dev/null
rm -r "$ALT/_Atari Tetris" >/dev/null
echo "merging _Arcades with missing files and folders"
mv -v $TEMP/_Arcade/*.mra /media/fat/_Arcade
mv -v "$TEMP/_Arcade/_alternatives/_Tetris" "$ALT"
mv -v "$TEMP/_Arcade/_alternatives/_Atari Tetris" "$ALT"
cd /media/fat
rm -r "$TEMP"