 #!/bin/bash  

sh ./install.sh 

# redirect stdout/stderr to a file
#exec >run.txt 2>&1


OutputRoot=/media/fat/_Arcade/_Coin-Op
echo "Creating/replacing $OutputRoot"
if [ -d "$OutputRoot" ]; then
   rm -r $OutputRoot >/dev/null
fi
mkdir -p $OutputRoot

echo "Creating $OutputRoot/_Atari"
sh ./folders/atari.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Bagman"
sh ./folders/bagman.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Bally-Midway"
sh ./folders/Ballymidway.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Capcom"
sh ./folders/capcom.sh "$OutputRoot"

echo "Creating $OutputRoot/_Cave"
sh ./folders/cave.sh "$OutputRoot" 

echo "Creating $OutputRoot/_CPS1"
sh ./folders/cps1.sh "$OutputRoot" 

echo "Creating $OutputRoot/_CPS1.5"
sh ./folders/cps1.5.sh "$OutputRoot" 

echo "Creating $OutputRoot/_CPS2"
sh ./folders/cps2.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Crazy Kong"
sh ./folders/crazykong.sh "$OutputRoot"

echo "Creating $OutputRoot/_Data East-Deco"
sh ./folders/deco.sh "$OutputRoot"

echo "Creating $OutputRoot/_Galaxian"
sh ./folders/galaxian.sh "$OutputRoot"

echo "Creating $OutputRoot/_Gottlieb"
sh ./folders/gottlieb.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Irem"
sh ./folders/irem.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Irem-M62 "
sh ./folders/iremm62.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Konami"
sh ./folders/konami.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Ladybug"
sh ./folders/ladybug.sh "$OutputRoot" 

echo "Creating $OutputRoot/_MCR1 "
sh ./folders/mcr1.sh "$OutputRoot" 

echo "Creating $OutputRoot/_MCR2 "
sh ./folders/mcr2.sh "$OutputRoot"

echo "Creating $OutputRoot/_MCR3 "
sh ./folders/mcr3.sh "$OutputRoot"

echo "Creating $OutputRoot/_MCR3Mono "
sh ./folders/mcr3mono.sh "$OutputRoot" 

echo "Creating $OutputRoot/_MCR3Scroll "
sh ./folders/mcr3scroll.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Namco"
sh ./folders/namco.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Nintendo"
sh ./folders/nintendo.sh "$OutputRoot" 

echo "Creating $OutputRoot/_Pacman"
sh ./folders/pacman.sh "$OutputRoot"

echo "Creating $OutputRoot/_Robotron"
sh ./folders/robotron.sh "$OutputRoot"

echo "Creating $OutputRoot/_Scramble"
sh ./folders/scramble.sh "$OutputRoot"

echo "Creating $OutputRoot/_Sega"
sh ./folders/sega.sh "$OutputRoot"

echo "Creating $OutputRoot/_Sega-System1 "
sh ./folders/segasys1.sh "$OutputRoot"

echo "Creating $OutputRoot/_Sega-System16 "
sh ./folders/segasys16.sh "$OutputRoot"

echo "Creating $OutputRoot/_SNK"
sh ./folders/snk.sh "$OutputRoot"

echo "Creating $OutputRoot/_Space Invaders"
sh ./folders/si.sh "$OutputRoot"

echo "Creating $OutputRoot/_Taito"
sh ./folders/taito.sh "$OutputRoot"

echo "Creating $OutputRoot/_Technos"
sh ./folders/technos.sh "$OutputRoot"

echo "Creating $OutputRoot/_Tehkan-Tecmo"
sh ./folders/Tehkan-Tecmo.sh "$OutputRoot"

echo "Creating $OutputRoot/_Universal"
sh ./folders/universal.sh "$OutputRoot"

echo "Creating $OutputRoot/_Upl"
sh ./folders/upl.sh "$OutputRoot"

echo "Creating $OutputRoot/_Williams"
sh ./folders/williams.sh "$OutputRoot"



